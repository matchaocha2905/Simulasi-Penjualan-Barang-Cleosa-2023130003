package main;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.layout.AnchorPane;

public class MainController {

	@FXML
	private AnchorPane contentArea;

	// Load halaman customer
	@FXML
	private void openCustomerPage() throws IOException {
		// ini buat jadi ketika di triger si fungsi nya lempar ke page customer.fxml
		loadPage("/customer/customer.fxml");
	}

	// Load halaman barang (nanti bisa ditambah)
	@FXML
	private void openBarangPage() throws IOException{
		loadPage("/barang/barang.fxml");
	}

	@FXML
	private void openUserPage() throws IOException{
		loadPage("/user/user.fxml");
	}

	@FXML
	private void openCabangPage() throws IOException{
		loadPage("/cabang/cabang.fxml");
	}

	// ini nanti aja
	@FXML
	private void openPembelianPage() {
		System.out.println("Menu Penjualan diklik - belum ada halaman.");
	}

	@FXML
	private void openPenjualanPage() {
		System.out.println("Menu Penjualan diklik - belum ada halaman.");
	}

	private void loadPage(String fxmlPath) throws IOException {
		Node node = FXMLLoader.load(getClass().getResource(fxmlPath));
		contentArea.getChildren().setAll(node);
	}
}
