package barang;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

public class BarangController implements Initializable {

    // --- FXML UI Components
    @FXML private TableView<Barang> tableBarang;
    @FXML private TableColumn<Barang, Integer> colId;
    @FXML private TableColumn<Barang, String> colNamaBarang;
    @FXML private TableColumn<Barang, String> colKode;
    @FXML private TableColumn<Barang, String> colTipe;
    @FXML private TableColumn<Barang, Double> colHargaBarang;
    @FXML private TableColumn<Barang, Double> colHargaJual;
    @FXML private TableColumn<Barang, Integer> colQuantity;

    @FXML private TextField txtNamaBarang;
    @FXML private TextField txtKode;
    @FXML private TextField txtTipe;
    @FXML private TextField txtHargaBarang;
    @FXML private TextField txtHargaJual;
    @FXML private TextField txtQuantity;

    // --- Database Connection Details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/db_penjualan";
    private static final String DB_USER = "root"; // GANTI DENGAN USER DATABASE ANDA
    private static final String DB_PASS = "";     // GANTI DENGAN PASSWORD DATABASE ANDA

    private ObservableList<Barang> barangList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Inisialisasi kolom tabel menggunakan PropertyValueFactory
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colKode.setCellValueFactory(new PropertyValueFactory<>("kode"));
        colNamaBarang.setCellValueFactory(new PropertyValueFactory<>("namaBarang"));
        colTipe.setCellValueFactory(new PropertyValueFactory<>("tipe"));
        colHargaBarang.setCellValueFactory(new PropertyValueFactory<>("hargaBarang"));
        colHargaJual.setCellValueFactory(new PropertyValueFactory<>("hargaJual"));
        colQuantity.setCellValueFactory(new PropertyValueFactory<>("quantity"));

        loadBarangData();
        
        // Listener untuk menampilkan data yang dipilih ke form
        tableBarang.getSelectionModel().selectedItemProperty().addListener(
            (observable, oldValue, newValue) -> showBarangDetails(newValue));
    }
    
    private void loadBarangData() {
        barangList.clear();
        String sql = "SELECT ID, Kode_Barang, Nama_Barang, Tipe_Barang, Harga_Barang, Harga_Jual, Quantity FROM barang";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Barang barang = new Barang(
                    rs.getInt("ID"),
                    rs.getString("Kode_Barang"),
                    rs.getString("Nama_Barang"),
                    rs.getString("Tipe_Barang"),
                    rs.getDouble("Harga_Barang"),
                    rs.getDouble("Harga_Jual"),
                    rs.getInt("Quantity")
                );
                barangList.add(barang);
            }
            tableBarang.setItems(barangList);

        } catch (SQLException e) {
            showAlert("Error Koneksi", "Gagal memuat data barang: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void showBarangDetails(Barang barang) {
        if (barang != null) {
            txtNamaBarang.setText(barang.getNamaBarang());
            txtKode.setText(barang.getKode());
            txtTipe.setText(barang.getTipe());
            txtHargaBarang.setText(String.valueOf(barang.getHargaBarang()));
            txtHargaJual.setText(String.valueOf(barang.getHargaJual()));
            txtQuantity.setText(String.valueOf(barang.getQuantity()));
        } else {
            clearFields();
        }
    }
    
    // --- FXML Event Handlers (CRUD)
    
    @FXML
    private void simpanData() {
        if (!validateInput()) return;
        
        String sql = "INSERT INTO barang (Kode_Barang, Nama_Barang, Tipe_Barang, Harga_Barang, Harga_Jual, Quantity) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, txtKode.getText());
            pstmt.setString(2, txtNamaBarang.getText());
            pstmt.setString(3, txtTipe.getText());
            pstmt.setDouble(4, Double.parseDouble(txtHargaBarang.getText()));
            pstmt.setDouble(5, Double.parseDouble(txtHargaJual.getText()));
            pstmt.setInt(6, Integer.parseInt(txtQuantity.getText()));

            pstmt.executeUpdate();
            showAlert("Sukses", "Data Barang berhasil ditambahkan.", Alert.AlertType.INFORMATION);
            loadBarangData(); 
            clearFields();

        } catch (SQLException | NumberFormatException e) {
            showAlert("Error Simpan", "Gagal menyimpan barang: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void ubahData() {
        Barang selectedBarang = tableBarang.getSelectionModel().getSelectedItem();
        if (selectedBarang == null) {
            showAlert("Peringatan", "Pilih data barang yang ingin diubah.", Alert.AlertType.WARNING);
            return;
        }
        if (!validateInput()) return;

        String sql = "UPDATE barang SET Kode_Barang=?, Nama_Barang=?, Tipe_Barang=?, Harga_Barang=?, Harga_Jual=?, Quantity=? WHERE ID=?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, txtKode.getText());
            pstmt.setString(2, txtNamaBarang.getText());
            pstmt.setString(3, txtTipe.getText());
            pstmt.setDouble(4, Double.parseDouble(txtHargaBarang.getText()));
            pstmt.setDouble(5, Double.parseDouble(txtHargaJual.getText()));
            pstmt.setInt(6, Integer.parseInt(txtQuantity.getText()));
            pstmt.setInt(7, selectedBarang.getId());

            pstmt.executeUpdate();
            showAlert("Sukses", "Data Barang berhasil diubah.", Alert.AlertType.INFORMATION);
            loadBarangData();
            clearFields();

        } catch (SQLException | NumberFormatException e) {
            showAlert("Error Ubah", "Gagal mengubah barang: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void hapusData() {
        Barang selectedBarang = tableBarang.getSelectionModel().getSelectedItem();
        if (selectedBarang == null) {
            showAlert("Peringatan", "Pilih data barang yang ingin dihapus.", Alert.AlertType.WARNING);
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION, "Yakin ingin menghapus barang " + selectedBarang.getNamaBarang() + "?", ButtonType.YES, ButtonType.NO);
        confirm.showAndWait();

        if (confirm.getResult() == ButtonType.YES) {
            String sql = "DELETE FROM barang WHERE ID = ?";
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setInt(1, selectedBarang.getId());
                pstmt.executeUpdate();

                showAlert("Sukses", "Data Barang berhasil dihapus.", Alert.AlertType.INFORMATION);
                loadBarangData();
                clearFields();

            } catch (SQLException e) {
                showAlert("Error Hapus", "Gagal menghapus barang: " + e.getMessage() + "\nPastikan barang tidak terkait dengan detail transaksi penjualan.", Alert.AlertType.ERROR);
            }
        }
    }

    @FXML
    private void clearFields() {
        txtNamaBarang.clear();
        txtKode.clear();
        txtTipe.clear();
        txtHargaBarang.clear();
        txtHargaJual.clear();
        txtQuantity.clear();
        tableBarang.getSelectionModel().clearSelection();
    }
    
    private boolean validateInput() {
        // Logika validasi data (misalnya, memastikan field tidak kosong dan harga adalah angka)
        if (txtNamaBarang.getText().isEmpty() || txtKode.getText().isEmpty() || txtHargaBarang.getText().isEmpty() || txtHargaJual.getText().isEmpty() || txtQuantity.getText().isEmpty()) {
            showAlert("Validasi Gagal", "Semua kolom wajib diisi.", Alert.AlertType.WARNING);
            return false;
        }
        
        try {
            Double.parseDouble(txtHargaBarang.getText());
            Double.parseDouble(txtHargaJual.getText());
            Integer.parseInt(txtQuantity.getText());
        } catch (NumberFormatException e) {
            showAlert("Validasi Gagal", "Harga dan Quantity harus berupa angka yang valid.", Alert.AlertType.WARNING);
            return false;
        }
        return true;
    }
    
    private void showAlert(String title, String content, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}