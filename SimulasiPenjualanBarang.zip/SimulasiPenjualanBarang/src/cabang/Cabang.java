package cabang;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Cabang {
    // Properti JavaFX
    private final SimpleIntegerProperty id;
    private final SimpleStringProperty namaCabang;
    private final SimpleStringProperty alamatCabang;

    // Constructor
    public Cabang(int id, String namaCabang, String alamatCabang) {
        this.id = new SimpleIntegerProperty(id);
        this.namaCabang = new SimpleStringProperty(namaCabang);
        this.alamatCabang = new SimpleStringProperty(alamatCabang);
    }
    
    // --- GETTERS WAJIB (Untuk Controller dan TableView) ---
    
    public int getId() { 
        return id.get(); 
    }
    
    public String getNamaCabang() { 
        return namaCabang.get(); 
    }
    
    public String getAlamatCabang() { 
        return alamatCabang.get(); 
    }
    
    // --- Property Getters (Digunakan oleh PropertyValueFactory) ---
    public SimpleIntegerProperty idProperty() { return id; }
    public SimpleStringProperty namaCabangProperty() { return namaCabang; }
    public SimpleStringProperty alamatCabangProperty() { return alamatCabang; }
}