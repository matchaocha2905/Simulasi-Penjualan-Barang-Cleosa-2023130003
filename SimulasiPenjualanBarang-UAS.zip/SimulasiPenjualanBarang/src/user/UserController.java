package user;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

public class UserController implements Initializable {

    // FXML UI Components (fx:id harus sesuai dengan User.fxml)
    @FXML private TableView<User> userTable;
    @FXML private TableColumn<User, Integer> colID;
    @FXML private TableColumn<User, String> colNama;
    @FXML private TableColumn<User, String> colEmail;
    @FXML private TableColumn<User, String> colTelepon;
    @FXML private TableColumn<User, Integer> colIDCabang;

    @FXML private TextField txtNama;
    @FXML private TextField txtEmail;
    @FXML private TextField txtTelepon;
    @FXML private TextArea txtAlamat;
    @FXML private PasswordField txtPassword;
    @FXML private ComboBox<Integer> cmbIdCabang; // Untuk foreign key ID_Cabang

    // Database Connection Details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/db_penjualan";
    private static final String DB_USER = "root"; // GANTI DENGAN USER DATABASE ANDA
    private static final String DB_PASS = "";     // GANTI DENGAN PASSWORD DATABASE ANDA

    private ObservableList<User> userList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Inisialisasi kolom tabel
        colID.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNama.setCellValueFactory(new PropertyValueFactory<>("namaUser"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        colTelepon.setCellValueFactory(new PropertyValueFactory<>("noTlpUser"));
        colIDCabang.setCellValueFactory(new PropertyValueFactory<>("idCabang"));

        loadCabangIDs(); // Muat ID Cabang untuk ComboBox
        loadUserData();  // Muat data pengguna

        // Listener untuk memilih item di tabel
        userTable.getSelectionModel().selectedItemProperty().addListener(
            (observable, oldValue, newValue) -> showUserDetails(newValue));
    }

    // Memuat daftar ID Cabang dari tabel 'cabang'
    private void loadCabangIDs() {
        ObservableList<Integer> cabangIDs = FXCollections.observableArrayList();
        String sql = "SELECT ID FROM cabang";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                cabangIDs.add(rs.getInt("ID"));
            }
            cmbIdCabang.setItems(cabangIDs);

        } catch (SQLException e) {
            showAlert("Error Koneksi", "Gagal memuat ID Cabang: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    // Memuat data pengguna dari tabel 'user'
    private void loadUserData() {
        userList.clear();
        String sql = "SELECT ID, ID_Cabang, Nama_User, No_Tlp_User, Alamat_User, Email FROM user";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                User user = new User(
                    rs.getInt("ID"),
                    rs.getInt("ID_Cabang"),
                    rs.getString("Nama_User"),
                    rs.getString("No_Tlp_User"),
                    rs.getString("Alamat_User"),
                    rs.getString("Email")
                );
                userList.add(user);
            }
            userTable.setItems(userList);

        } catch (SQLException e) {
            showAlert("Error Koneksi", "Gagal memuat data pengguna: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    // Menampilkan detail pengguna yang dipilih ke field input
    private void showUserDetails(User user) {
        if (user != null) {
            txtNama.setText(user.getNamaUser());
            txtEmail.setText(user.getEmail());
            txtTelepon.setText(user.getNoTlpUser());
            txtAlamat.setText(user.getAlamatUser());
            cmbIdCabang.getSelectionModel().select(user.getIdCabang());
            txtPassword.clear(); // Jangan pernah menampilkan password
        } else {
            clearFields();
        }
    }

    // --- FXML Event Handlers (CRUD)

    @FXML
    private void handleTambahUser() {
        if (validateInput()) {
            String sql = "INSERT INTO user (ID_Cabang, Nama_User, No_Tlp_User, Alamat_User, Email, Password) VALUES (?, ?, ?, ?, ?, ?)";
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setInt(1, cmbIdCabang.getValue());
                pstmt.setString(2, txtNama.getText());
                pstmt.setString(3, txtTelepon.getText());
                pstmt.setString(4, txtAlamat.getText());
                pstmt.setString(5, txtEmail.getText());
                // PERINGATAN: Gunakan hashing untuk Password di produksi!
                pstmt.setString(6, txtPassword.getText());

                pstmt.executeUpdate();
                showAlert("Sukses", "Data Pengguna berhasil ditambahkan.", Alert.AlertType.INFORMATION);
                loadUserData();
                clearFields();

            } catch (SQLException e) {
                showAlert("Error Tambah", "Gagal menambahkan pengguna: " + e.getMessage(), Alert.AlertType.ERROR);
            }
        }
    }

    @FXML
    private void handleUbahUser() {
        User selectedUser = userTable.getSelectionModel().getSelectedItem();
        if (selectedUser != null && validateInput(false)) { // Parameter false agar tidak wajib input password
            String sql = "UPDATE user SET ID_Cabang=?, Nama_User=?, No_Tlp_User=?, Alamat_User=?, Email=? " +
                         (txtPassword.getText().isEmpty() ? "" : ", Password=? ") +
                         "WHERE ID=?";
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setInt(1, cmbIdCabang.getValue());
                pstmt.setString(2, txtNama.getText());
                pstmt.setString(3, txtTelepon.getText());
                pstmt.setString(4, txtAlamat.getText());
                pstmt.setString(5, txtEmail.getText());

                int paramIndex = 6;
                if (!txtPassword.getText().isEmpty()) {
                    // PERINGATAN: Gunakan hashing untuk Password di produksi!
                    pstmt.setString(paramIndex++, txtPassword.getText());
                }
                
                pstmt.setInt(paramIndex, selectedUser.getId());

                pstmt.executeUpdate();
                showAlert("Sukses", "Data Pengguna berhasil diubah.", Alert.AlertType.INFORMATION);
                loadUserData();
                clearFields();

            } catch (SQLException e) {
                showAlert("Error Ubah", "Gagal mengubah pengguna: " + e.getMessage(), Alert.AlertType.ERROR);
            }
        } else if (selectedUser == null) {
            showAlert("Peringatan", "Pilih data pengguna yang ingin diubah.", Alert.AlertType.WARNING);
        }
    }

    @FXML
    private void handleHapusUser() {
        User selectedUser = userTable.getSelectionModel().getSelectedItem();
        if (selectedUser != null) {
            String sql = "DELETE FROM user WHERE ID = ?";
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setInt(1, selectedUser.getId());
                pstmt.executeUpdate();

                showAlert("Sukses", "Data Pengguna berhasil dihapus.", Alert.AlertType.INFORMATION);
                loadUserData();
                clearFields();

            } catch (SQLException e) {
                showAlert("Error Hapus", "Gagal menghapus pengguna: " + e.getMessage() + "\nPastikan pengguna tidak terkait dengan transaksi Selling.", Alert.AlertType.ERROR);
            }
        } else {
            showAlert("Peringatan", "Pilih data pengguna yang ingin dihapus.", Alert.AlertType.WARNING);
        }
    }

    // --- Metode Pembantu

    private boolean validateInput() {
        return validateInput(true); // Default: password wajib
    }

    private boolean validateInput(boolean isPasswordRequired) {
        String errorMessage = "";

        if (txtNama.getText() == null || txtNama.getText().isEmpty()) {
            errorMessage += "Nama User tidak boleh kosong!\n";
        }
        if (cmbIdCabang.getValue() == null) {
            errorMessage += "ID Cabang harus dipilih!\n";
        }
        if (isPasswordRequired && (txtPassword.getText() == null || txtPassword.getText().isEmpty())) {
             errorMessage += "Password tidak boleh kosong!\n";
        }
        // Anda bisa menambahkan validasi lain seperti format email/telepon di sini

        if (errorMessage.isEmpty()) {
            return true;
        } else {
            showAlert("Input Tidak Valid", errorMessage, Alert.AlertType.ERROR);
            return false;
        }
    }
    
    private void clearFields() {
        txtNama.clear();
        txtEmail.clear();
        txtTelepon.clear();
        txtAlamat.clear();
        txtPassword.clear();
        cmbIdCabang.getSelectionModel().clearSelection();
        userTable.getSelectionModel().clearSelection();
    }
    
    private void showAlert(String title, String content, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}