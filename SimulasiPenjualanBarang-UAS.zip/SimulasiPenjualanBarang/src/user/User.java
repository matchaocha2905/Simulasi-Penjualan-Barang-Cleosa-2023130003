package user;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class User {

    private final SimpleIntegerProperty id;
    private final SimpleIntegerProperty idCabang;
    private final SimpleStringProperty namaUser;
    private final SimpleStringProperty noTlpUser;
    private final SimpleStringProperty alamatUser;
    private final SimpleStringProperty email;
    // Password tidak disertakan sebagai properti yang dapat dilihat di UI

    public User(int id, int idCabang, String namaUser, String noTlpUser, String alamatUser, String email) {
        this.id = new SimpleIntegerProperty(id);
        this.idCabang = new SimpleIntegerProperty(idCabang);
        this.namaUser = new SimpleStringProperty(namaUser);
        this.noTlpUser = new SimpleStringProperty(noTlpUser);
        this.alamatUser = new SimpleStringProperty(alamatUser);
        this.email = new SimpleStringProperty(email);
    }

    // Getters untuk data
    public int getId() {
        return id.get();
    }

    public int getIdCabang() {
        return idCabang.get();
    }

    public String getNamaUser() {
        return namaUser.get();
    }

    public String getNoTlpUser() {
        return noTlpUser.get();
    }

    public String getAlamatUser() {
        return alamatUser.get();
    }

    public String getEmail() {
        return email.get();
    }

    // Property Getters (Wajib untuk TableView JavaFX)
    public SimpleIntegerProperty idProperty() {
        return id;
    }

    public SimpleIntegerProperty idCabangProperty() {
        return idCabang;
    }

    public SimpleStringProperty namaUserProperty() {
        return namaUser;
    }

    public SimpleStringProperty noTlpUserProperty() {
        return noTlpUser;
    }

    public SimpleStringProperty alamatUserProperty() {
        return alamatUser;
    }

    public SimpleStringProperty emailProperty() {
        return email;
    }
}