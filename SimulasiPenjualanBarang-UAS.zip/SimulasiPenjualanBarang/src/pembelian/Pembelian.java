package pembelian; // PACKAGE DITETAPKAN DI SINI

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Pembelian {

    // Kolom sesuai dengan SQL (ID, ID_User, Total_Harga, Supplier)
    private final IntegerProperty id;
    private final IntegerProperty idUser;
    private final DoubleProperty totalHarga; 
    private final StringProperty supplier;   

    // Konstruktor
    public Pembelian(int id, int idUser, double totalHarga, String supplier) {
        this.id = new SimpleIntegerProperty(id);
        this.idUser = new SimpleIntegerProperty(idUser);
        this.totalHarga = new SimpleDoubleProperty(totalHarga);
        this.supplier = new SimpleStringProperty(supplier);
    }

    // --- Getter Properti ---
    public IntegerProperty idProperty() { return id; }
    public IntegerProperty idUserProperty() { return idUser; }
    public DoubleProperty totalHargaProperty() { return totalHarga; }
    public StringProperty supplierProperty() { return supplier; }

    // --- Getter Nilai ---
    public int getId() { return id.get(); }
    public int getIdUser() { return idUser.get(); }
    public double getTotalHarga() { return totalHarga.get(); }
    public String getSupplier() { return supplier.get(); }

    // --- Setter Nilai ---
    public void setId(int id) { this.id.set(id); }
    public void setIdUser(int idUser) { this.idUser.set(idUser); }
    public void setTotalHarga(double totalHarga) { this.totalHarga.set(totalHarga); }
    public void setSupplier(String supplier) { this.supplier.set(supplier); }
}