package pembelian; // PACKAGE DITETAPKAN DI SINI

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
// Catatan: Kelas Pembelian (Model) berada di package yang sama (pembelian)

public class PembelianController implements Initializable {

    // --- FXML Components (sesuai Pembelian.fxml) ---
    @FXML private TableView<Pembelian> pembelianTable; 
    @FXML private TableColumn<Pembelian, Integer> idColumn;
    @FXML private TableColumn<Pembelian, Integer> idUserColumn;
    @FXML private TableColumn<Pembelian, Double> totalHargaColumn;
    @FXML private TableColumn<Pembelian, String> supplierColumn;

    private ObservableList<Pembelian> dataPembelian;

    // --- Inisialisasi ---
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initColumns();
        loadData();
    }

    private void initColumns() {
        // Menghubungkan kolom tabel dengan properti di kelas Pembelian.java
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        idUserColumn.setCellValueFactory(new PropertyValueFactory<>("idUser"));
        totalHargaColumn.setCellValueFactory(new PropertyValueFactory<>("totalHarga"));
        supplierColumn.setCellValueFactory(new PropertyValueFactory<>("supplier"));
    }

    private void loadData() {
        // Contoh data dummy:
        dataPembelian = FXCollections.observableArrayList(
            new Pembelian(1, 101, 750000.00, "PT. Sinar Abadi"),
            new Pembelian(2, 102, 1200000.50, "CV. Mitra Jaya"),
            new Pembelian(3, 101, 50000.00, "Toko Lokal")
        );
        pembelianTable.setItems(dataPembelian);
    }
    
    // ====================================================================
    // METODE UNTUK MENANGANI AKSI TOMBOL (sesuai dengan onAction di FXML)
    // ====================================================================

    @FXML
    private void handleTambahPembelian() {
        System.out.println("Tombol Tambah Pembelian ditekan.");
        // TODO: Logika untuk membuka form input/dialog box untuk tambah data baru
    }

    @FXML
    private void handleEditPembelian() {
        System.out.println("Tombol Edit Pembelian ditekan.");
        // TODO: Logika untuk mendapatkan item yang dipilih di tabel dan membuka form edit
    }

    @FXML
    private void handleHapusPembelian() {
        System.out.println("Tombol Hapus Pembelian ditekan.");
        // TODO: Logika untuk mengkonfirmasi dan menghapus item yang dipilih dari list dan database
    }
}