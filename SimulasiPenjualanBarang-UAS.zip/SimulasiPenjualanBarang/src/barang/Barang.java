package barang;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Barang {
    
    // Properti sesuai tabel SQL: ID, Kode_Barang, Nama_Barang, Tipe_Barang, Harga_Barang, Harga_Jual, Quantity
    private final SimpleIntegerProperty id;
    private final SimpleStringProperty kode;
    private final SimpleStringProperty namaBarang;
    private final SimpleStringProperty tipe;
    private final SimpleDoubleProperty hargaBarang; // Harga Beli
    private final SimpleDoubleProperty hargaJual;
    private final SimpleIntegerProperty quantity;

    public Barang(int id, String kode, String namaBarang, String tipe, double hargaBarang, double hargaJual, int quantity) {
        this.id = new SimpleIntegerProperty(id);
        this.kode = new SimpleStringProperty(kode);
        this.namaBarang = new SimpleStringProperty(namaBarang);
        this.tipe = new SimpleStringProperty(tipe);
        this.hargaBarang = new SimpleDoubleProperty(hargaBarang);
        this.hargaJual = new SimpleDoubleProperty(hargaJual);
        this.quantity = new SimpleIntegerProperty(quantity);
    }

    // --- Getters untuk data
    public int getId() { return id.get(); }
    public String getKode() { return kode.get(); }
    public String getNamaBarang() { return namaBarang.get(); }
    public String getTipe() { return tipe.get(); }
    public double getHargaBarang() { return hargaBarang.get(); }
    public double getHargaJual() { return hargaJual.get(); }
    public int getQuantity() { return quantity.get(); }

    // --- Property Getters (Wajib untuk TableView JavaFX)
    public SimpleIntegerProperty idProperty() { return id; }
    public SimpleStringProperty kodeProperty() { return kode; }
    public SimpleStringProperty namaBarangProperty() { return namaBarang; }
    public SimpleStringProperty tipeProperty() { return tipe; }
    public SimpleDoubleProperty hargaBarangProperty() { return hargaBarang; }
    public SimpleDoubleProperty hargaJualProperty() { return hargaJual; }
    public SimpleIntegerProperty quantityProperty() { return quantity; }
}