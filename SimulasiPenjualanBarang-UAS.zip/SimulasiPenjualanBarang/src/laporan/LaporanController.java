package laporan;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class LaporanController implements Initializable {

    // --- FXML Components ---
    @FXML private DatePicker datePickerStart;
    @FXML private DatePicker datePickerEnd;
    @FXML private TableView<Laporan> laporanTable; 
    @FXML private TableColumn<Laporan, String> namaBarangColumn;
    @FXML private TableColumn<Laporan, String> kodeBarangColumn;
    @FXML private TableColumn<Laporan, Integer> kuantitasColumn;
    @FXML private TableColumn<Laporan, Double> omsetColumn;
    @FXML private TableColumn<Laporan, Double> profitColumn;

    private ObservableList<Laporan> dataLaporan;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initColumns();
        
        // Set tanggal default untuk filter
        datePickerStart.setValue(LocalDate.now().minusDays(30));
        datePickerEnd.setValue(LocalDate.now());
        
        // Muat data awal
        loadReportData(datePickerStart.getValue(), datePickerEnd.getValue());
    }

    private void initColumns() {
        // Menghubungkan kolom tabel dengan properti di kelas LaporanProdukModel.java
        namaBarangColumn.setCellValueFactory(new PropertyValueFactory<>("namaBarang"));
        kodeBarangColumn.setCellValueFactory(new PropertyValueFactory<>("kodeBarang"));
        kuantitasColumn.setCellValueFactory(new PropertyValueFactory<>("totalKuantitas"));
        omsetColumn.setCellValueFactory(new PropertyValueFactory<>("totalOmset"));
        profitColumn.setCellValueFactory(new PropertyValueFactory<>("totalProfit"));
    }

    @FXML
    private void handleGenerateReport() {
        LocalDate start = datePickerStart.getValue();
        LocalDate end = datePickerEnd.getValue();
        
        if (start == null || end == null) {
             Alert alert = new Alert(AlertType.WARNING, "Silakan pilih Tanggal Awal dan Tanggal Akhir.", ButtonType.OK);
             alert.showAndWait();
             return;
        }
        
        loadReportData(start, end);
        
        Alert alert = new Alert(AlertType.INFORMATION, "Laporan berhasil dimuat untuk periode " + start + " hingga " + end, ButtonType.OK);
        alert.setHeaderText("Laporan Berhasil");
        alert.showAndWait();
    }

    /**
     * Metode utama untuk memuat data laporan dari database.
     * @param startDate Tanggal mulai filter.
     * @param endDate Tanggal akhir filter.
     */
    private void loadReportData(LocalDate startDate, LocalDate endDate) {
        // =========================================================================
        // TODO: IMPLEMENTASI KONEKSI DATABASE (JDBC) DI SINI
        // Query SQL seharusnya: JOIN selling, detail_selling, dan barang.
        // Kemudian GROUP BY nama_barang dan Kode_Barang.
        // Hitung SUM(Quantity), SUM(Harga_Jual * Quantity), dan SUM(Profit).
        // =========================================================================
        
        System.out.println("Mencoba memuat data laporan dari " + startDate + " hingga " + endDate);

        // --- Contoh Data Dummy ---
        dataLaporan = FXCollections.observableArrayList(
            new Laporan("Laptop X-Pro 15", "LTX15", 5, 50000000.00, 10000000.00),
            new Laporan("Mouse Wireless M3", "MWM03", 45, 1350000.00, 450000.00),
            new Laporan("Keyboard Mekanik K5", "KMK05", 20, 4000000.00, 1200000.00)
        );
        
        laporanTable.setItems(dataLaporan);
    }
}