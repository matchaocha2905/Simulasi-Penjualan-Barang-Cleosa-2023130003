/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package laporan;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author Clepie
 */
public class Laporan {
   private final StringProperty namaBarang;
    private final StringProperty kodeBarang;
    private final IntegerProperty totalKuantitas;
    private final DoubleProperty totalOmset; // Total Harga Jual
    private final DoubleProperty totalProfit; // Total Keuntungan 
    
    public Laporan(String namaBarang, String kodeBarang, int totalKuantitas, double totalOmset, double totalProfit) {
        this.namaBarang = new SimpleStringProperty(namaBarang);
        this.kodeBarang = new SimpleStringProperty(kodeBarang);
        this.totalKuantitas = new SimpleIntegerProperty(totalKuantitas);
        this.totalOmset = new SimpleDoubleProperty(totalOmset);
        this.totalProfit = new SimpleDoubleProperty(totalProfit);
}
    
// --- Getter Properti ---
    public StringProperty namaBarangProperty() { return namaBarang; }
    public StringProperty kodeBarangProperty() { return kodeBarang; }
    public IntegerProperty totalKuantitasProperty() { return totalKuantitas; }
    public DoubleProperty totalOmsetProperty() { return totalOmset; }
    public DoubleProperty totalProfitProperty() { return totalProfit; }

    // --- Getter Nilai ---
    public String getNamaBarang() { return namaBarang.get(); }
    public String getKodeBarang() { return kodeBarang.get(); }
    public int getTotalKuantitas() { return totalKuantitas.get(); }
    public double getTotalOmset() { return totalOmset.get(); }
    public double getTotalProfit() { return totalProfit.get(); }
}
