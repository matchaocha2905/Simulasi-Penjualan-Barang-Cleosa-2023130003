package cabang;

// --- Imports Wajib
import javafx.fxml.FXML; 
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class CabangController implements Initializable {

    // --- FXML UI Components
    @FXML private TableView<Cabang> tableCabang;
    @FXML private TableColumn<Cabang, Integer> colId;
    @FXML private TableColumn<Cabang, String> colNamaCabang;
    @FXML private TableColumn<Cabang, String> colAlamatCabang; 

    @FXML private TextField txtNamaCabang;
    @FXML private TextArea txtAlamatCabang; // Menggunakan TextArea
    
    @FXML private Button btnSimpan;
    @FXML private Button btnUbah;
    @FXML private Button btnHapus;
    @FXML private Button btnBatal;

    // --- Database Connection Details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/db_penjualan"; 
    private static final String DB_USER = "root"; 
    private static final String DB_PASS = "";     

    private ObservableList<Cabang> cabangList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Inisialisasi kolom tabel
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNamaCabang.setCellValueFactory(new PropertyValueFactory<>("namaCabang"));
        colAlamatCabang.setCellValueFactory(new PropertyValueFactory<>("alamatCabang"));

        loadCabangData();
        
        // Listener untuk menampilkan data yang dipilih ke form
        tableCabang.getSelectionModel().selectedItemProperty().addListener(
            (observable, oldValue, newValue) -> showCabangDetails(newValue));
    }
    
    // ---------------------- UTILITIES ----------------------
    
    private void loadCabangData() {
        cabangList.clear();
        // SELECT berdasarkan skema db_penjualan.sql
        String sql = "SELECT ID, Nama_Cabang, Alamat_Cabang FROM cabang"; 
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Cabang cabang = new Cabang(
                    rs.getInt("ID"),
                    rs.getString("Nama_Cabang"),
                    rs.getString("Alamat_Cabang")
                );
                cabangList.add(cabang);
            }
            tableCabang.setItems(cabangList);

        } catch (SQLException e) {
            showAlert("Error Koneksi", "Gagal memuat data cabang: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void showCabangDetails(Cabang cabang) {
        if (cabang != null) {
            txtNamaCabang.setText(cabang.getNamaCabang());
            txtAlamatCabang.setText(cabang.getAlamatCabang());
        } else {
            clearFields();
        }
    }
    
    private boolean validateInput() {
        if (txtNamaCabang.getText().trim().isEmpty() || txtAlamatCabang.getText().trim().isEmpty()) {
            showAlert("Validasi Gagal", "Nama Cabang dan Alamat wajib diisi.", Alert.AlertType.WARNING);
            return false;
        }
        return true;
    }
    
    private void showAlert(String title, String content, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
    
    // ---------------------- CRUD HANDLERS ----------------------
    
    @FXML
    private void simpanData() { 
        if (!validateInput()) return;
        
        String sql = "INSERT INTO cabang (Nama_Cabang, Alamat_Cabang) VALUES (?, ?)";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, txtNamaCabang.getText());
            pstmt.setString(2, txtAlamatCabang.getText());

            pstmt.executeUpdate();
            showAlert("Sukses", "Data Cabang berhasil ditambahkan.", Alert.AlertType.INFORMATION);
            loadCabangData(); 
            clearFields();

        } catch (SQLException e) {
            showAlert("Error Simpan", "Gagal menyimpan cabang: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void ubahData() {
        Cabang selectedCabang = tableCabang.getSelectionModel().getSelectedItem();
        if (selectedCabang == null) {
            showAlert("Peringatan", "Pilih data cabang yang ingin diubah.", Alert.AlertType.WARNING);
            return;
        }
        if (!validateInput()) return;

        String sql = "UPDATE cabang SET Nama_Cabang=?, Alamat_Cabang=? WHERE ID=?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, txtNamaCabang.getText());
            pstmt.setString(2, txtAlamatCabang.getText());
            pstmt.setInt(3, selectedCabang.getId());

            pstmt.executeUpdate();
            showAlert("Sukses", "Data Cabang berhasil diubah.", Alert.AlertType.INFORMATION);
            loadCabangData();
            clearFields();

        } catch (SQLException e) {
            showAlert("Error Ubah", "Gagal mengubah cabang: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void hapusData() {
        Cabang selectedCabang = tableCabang.getSelectionModel().getSelectedItem();
        if (selectedCabang == null) {
            showAlert("Peringatan", "Pilih data cabang yang ingin dihapus.", Alert.AlertType.WARNING);
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION, "Yakin ingin menghapus cabang " + selectedCabang.getNamaCabang() + "?", ButtonType.YES, ButtonType.NO);
        confirm.showAndWait();

        if (confirm.getResult() == ButtonType.YES) {
            String sql = "DELETE FROM cabang WHERE ID = ?";
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setInt(1, selectedCabang.getId());
                pstmt.executeUpdate();

                showAlert("Sukses", "Data Cabang berhasil dihapus.", Alert.AlertType.INFORMATION);
                loadCabangData();
                clearFields();

            } catch (SQLException e) {
                showAlert("Error Hapus", "Gagal menghapus cabang: " + e.getMessage() + "\nPastikan tidak ada User atau Transaksi yang terhubung dengan cabang ini.", Alert.AlertType.ERROR);
            }
        }
    }
    
    @FXML
    private void clearFields() { 
        txtNamaCabang.clear();
        txtAlamatCabang.clear();
        tableCabang.getSelectionModel().clearSelection();
    }
}