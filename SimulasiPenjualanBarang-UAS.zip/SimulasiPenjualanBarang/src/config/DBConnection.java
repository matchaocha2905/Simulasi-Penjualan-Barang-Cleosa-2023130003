package config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	// nanti sesuain sama nama tabel kamu ya ini nama nya posjava kamu sesuaiin aja
	// posjava nya sama yang kamu butuh
	private static final String URL = "jdbc:mysql://localhost:3306/db_penjualan";
	private static final String USER = "root"; // ubah jika perlu
	private static final String PASS = ""; // ubah jika perlu

	private static Connection conn;

	public static Connection getConnection() {
		try {
			if (conn == null || conn.isClosed()) {
				Class.forName("com.mysql.cj.jdbc.Driver");
				conn = DriverManager.getConnection(URL, USER, PASS);
				System.out.println("✅ Koneksi ke database berhasil");
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			System.out.println("❌ Gagal koneksi ke database");
		}
		return conn;
	}
}
