package customer;

// --- Imports Wajib untuk JavaFX dan SQL
import javafx.fxml.FXML; 
import javafx.fxml.Initializable; // Mengatasi 'cannot find symbol: class Initializable'
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class CustomerController implements Initializable {

    // --- FXML UI Components (fx:id dari Customer.fxml)
    @FXML private TableView<Customer> tableCustomer;
    @FXML private TableColumn<Customer, Integer> colId;
    @FXML private TableColumn<Customer, String> colNama;
    @FXML private TableColumn<Customer, String> colNoTlp;
    @FXML private TableColumn<Customer, String> colAlamat;
    @FXML private TableColumn<Customer, String> colEmail; 

    @FXML private TextField txtNama;
    @FXML private TextField txtNoTlp;
    @FXML private TextArea txtAlamat; // Menggunakan TextArea
    @FXML private TextField txtEmail;
    
    // Tombol Aksi 
    @FXML private Button btnSimpan;
    @FXML private Button btnUbah;
    @FXML private Button btnHapus;
    @FXML private Button btnBatal;

    // --- Database Connection Details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/db_penjualan"; 
    private static final String DB_USER = "root"; // GANTI DENGAN USER DATABASE ANDA
    private static final String DB_PASS = "";     // GANTI DENGAN PASSWORD DATABASE ANDA

    private ObservableList<Customer> customerList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Inisialisasi kolom tabel, menghubungkan ke properti di Customer.java (Model)
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNama.setCellValueFactory(new PropertyValueFactory<>("nama"));
        colNoTlp.setCellValueFactory(new PropertyValueFactory<>("noTlp"));
        colAlamat.setCellValueFactory(new PropertyValueFactory<>("alamat"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email")); 

        loadCustomerData();
        
        // Listener: Ketika baris dipilih, tampilkan detail di form input
        tableCustomer.getSelectionModel().selectedItemProperty().addListener(
            (observable, oldValue, newValue) -> showCustomerDetails(newValue));
    }
    
    // ---------------------- UTILITIES ----------------------
    
    private void loadCustomerData() {
        customerList.clear();
        String sql = "SELECT ID, Nama_Cust, No_Tlp_Cust, Alamat_Cust, Email FROM customer";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                // Pastikan constructor Customer sesuai dengan urutan dan tipe data di sini
                Customer customer = new Customer(
                    rs.getInt("ID"),
                    rs.getString("Nama_Cust"),
                    rs.getString("No_Tlp_Cust"),
                    rs.getString("Alamat_Cust"),
                    rs.getString("Email")
                );
                customerList.add(customer);
            }
            tableCustomer.setItems(customerList);

        } catch (SQLException e) {
            showAlert("Error Koneksi", "Gagal memuat data customer dari database: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void showCustomerDetails(Customer customer) {
        if (customer != null) {
            txtNama.setText(customer.getNama());
            txtNoTlp.setText(customer.getNoTlp()); 
            txtAlamat.setText(customer.getAlamat());
            txtEmail.setText(customer.getEmail());
        } else {
            clearFields();
        }
    }
    
    private boolean validateInput() {
        if (txtNama.getText().trim().isEmpty() || txtNoTlp.getText().trim().isEmpty() || txtAlamat.getText().trim().isEmpty()) {
            showAlert("Validasi Gagal", "Kolom Nama, No Tlp, dan Alamat wajib diisi.", Alert.AlertType.WARNING);
            return false;
        }
        // Validasi email sederhana (jika tidak kosong)
        if (!txtEmail.getText().trim().isEmpty() && !txtEmail.getText().matches(".+@.+\\..+")) {
             showAlert("Validasi Gagal", "Format Email tidak valid.", Alert.AlertType.WARNING);
             return false;
        }
        return true;
    }
    
    private void showAlert(String title, String content, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
    
    // ---------------------- CRUD HANDLERS ----------------------
    
    @FXML
    private void simpanData() { 
        if (!validateInput()) return;
        
        String sql = "INSERT INTO customer (Nama_Cust, No_Tlp_Cust, Alamat_Cust, Email) VALUES (?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, txtNama.getText());
            pstmt.setString(2, txtNoTlp.getText());
            pstmt.setString(3, txtAlamat.getText());
            pstmt.setString(4, txtEmail.getText());

            pstmt.executeUpdate();
            showAlert("Sukses", "Data Customer berhasil ditambahkan.", Alert.AlertType.INFORMATION);
            loadCustomerData(); 
            clearFields();

        } catch (SQLException e) {
            showAlert("Error Simpan", "Gagal menyimpan customer: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void ubahData() {
        Customer selectedCustomer = tableCustomer.getSelectionModel().getSelectedItem();
        if (selectedCustomer == null) {
            showAlert("Peringatan", "Pilih data customer yang ingin diubah.", Alert.AlertType.WARNING);
            return;
        }
        if (!validateInput()) return;

        String sql = "UPDATE customer SET Nama_Cust=?, No_Tlp_Cust=?, Alamat_Cust=?, Email=? WHERE ID=?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, txtNama.getText());
            pstmt.setString(2, txtNoTlp.getText());
            pstmt.setString(3, txtAlamat.getText());
            pstmt.setString(4, txtEmail.getText());
            pstmt.setInt(5, selectedCustomer.getId());

            pstmt.executeUpdate();
            showAlert("Sukses", "Data Customer berhasil diubah.", Alert.AlertType.INFORMATION);
            loadCustomerData();
            clearFields();

        } catch (SQLException e) {
            showAlert("Error Ubah", "Gagal mengubah customer: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void hapusData() {
        Customer selectedCustomer = tableCustomer.getSelectionModel().getSelectedItem();
        if (selectedCustomer == null) {
            showAlert("Peringatan", "Pilih data customer yang ingin dihapus.", Alert.AlertType.WARNING);
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION, "Yakin ingin menghapus customer " + selectedCustomer.getNama() + "?", ButtonType.YES, ButtonType.NO);
        confirm.showAndWait();

        if (confirm.getResult() == ButtonType.YES) {
            String sql = "DELETE FROM customer WHERE ID = ?";
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setInt(1, selectedCustomer.getId());
                pstmt.executeUpdate();

                showAlert("Sukses", "Data Customer berhasil dihapus.", Alert.AlertType.INFORMATION);
                loadCustomerData();
                clearFields();

            } catch (SQLException e) {
                showAlert("Error Hapus", "Gagal menghapus customer: " + e.getMessage(), Alert.AlertType.ERROR);
            }
        }
    }
    
    @FXML
    private void clearFields() { 
        txtNama.clear();
        txtNoTlp.clear();
        txtAlamat.clear();
        txtEmail.clear();
        tableCustomer.getSelectionModel().clearSelection();
    }
}