package customer;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Customer {
    // Properti JavaFX untuk TableView (Sesuai dengan CustomerController)
    private final SimpleIntegerProperty id;
    private final SimpleStringProperty nama;
    private final SimpleStringProperty noTlp; // <--- PASTIKAN INI ADA
    private final SimpleStringProperty alamat;
    private final SimpleStringProperty email;

    // Constructor
    public Customer(int id, String nama, String noTlp, String alamat, String email) {
        this.id = new SimpleIntegerProperty(id);
        this.nama = new SimpleStringProperty(nama);
        this.noTlp = new SimpleStringProperty(noTlp);
        this.alamat = new SimpleStringProperty(alamat);
        this.email = new SimpleStringProperty(email);
    }
    
    // --- GETTERS WAJIB (Mengambil nilai untuk Controller dan TableView) ---
    
    public int getId() { 
        return id.get(); 
    }
    
    public String getNama() { 
        return nama.get(); 
    }
    
    public String getNoTlp() { // <--- METODE INI YANG DICARI CONTROLLER
        return noTlp.get(); 
    }
    
    public String getAlamat() { 
        return alamat.get(); 
    }
    
    public String getEmail() {
        return email.get();
    }
    
    // --- Opsional: Property Getters (Digunakan oleh PropertyValueFactory) ---
    public SimpleIntegerProperty idProperty() { return id; }
    public SimpleStringProperty namaProperty() { return nama; }
    public SimpleStringProperty noTlpProperty() { return noTlp; }
    public SimpleStringProperty alamatProperty() { return alamat; }
    public SimpleStringProperty emailProperty() { return email; }
}