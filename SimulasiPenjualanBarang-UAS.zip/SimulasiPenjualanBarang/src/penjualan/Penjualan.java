package model;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Penjualan {

    // Properties dari kolom SQL Anda
    private final IntegerProperty id;
    private final IntegerProperty idUser;
    private final IntegerProperty idCust;
    private final IntegerProperty idCabang;
    private final DoubleProperty totalHarga; // DECIMAL(15,2) -> DoubleProperty
    private final DoubleProperty payment;    // DECIMAL(15,2) -> DoubleProperty
    private final DoubleProperty kembalian;  // DECIMAL(15,2) -> DoubleProperty
    private final StringProperty tipeTransaksi; // VARCHAR(50) -> StringProperty
    private final StringProperty statusTransaksi; // VARCHAR(50) -> StringProperty

    // Konstruktor
    public Penjualan(int id, int idUser, int idCust, int idCabang, 
                     double totalHarga, double payment, double kembalian, 
                     String tipeTransaksi, String statusTransaksi) {
        this.id = new SimpleIntegerProperty(id);
        this.idUser = new SimpleIntegerProperty(idUser);
        this.idCust = new SimpleIntegerProperty(idCust);
        this.idCabang = new SimpleIntegerProperty(idCabang);
        this.totalHarga = new SimpleDoubleProperty(totalHarga);
        this.payment = new SimpleDoubleProperty(payment);
        this.kembalian = new SimpleDoubleProperty(kembalian);
        this.tipeTransaksi = new SimpleStringProperty(tipeTransaksi);
        this.statusTransaksi = new SimpleStringProperty(statusTransaksi);
    }

    // --- Getter untuk properti (Mengembalikan Property) ---
    public IntegerProperty idProperty() { return id; }
    public IntegerProperty idUserProperty() { return idUser; }
    public IntegerProperty idCustProperty() { return idCust; }
    public IntegerProperty idCabangProperty() { return idCabang; }
    public DoubleProperty totalHargaProperty() { return totalHarga; }
    public DoubleProperty paymentProperty() { return payment; }
    public DoubleProperty kembalianProperty() { return kembalian; }
    public StringProperty tipeTransaksiProperty() { return tipeTransaksi; }
    public StringProperty statusTransaksiProperty() { return statusTransaksi; }

    // --- Getter untuk nilai (Mengembalikan Nilai) ---
    public int getId() { return id.get(); }
    public int getIdUser() { return idUser.get(); }
    public int getIdCust() { return idCust.get(); }
    public int getIdCabang() { return idCabang.get(); }
    public double getTotalHarga() { return totalHarga.get(); }
    public double getPayment() { return payment.get(); }
    public double getKembalian() { return kembalian.get(); }
    public String getTipeTransaksi() { return tipeTransaksi.get(); }
    public String getStatusTransaksi() { return statusTransaksi.get(); }

    // --- Setter untuk nilai ---
    public void setId(int id) { this.id.set(id); }
    public void setIdUser(int idUser) { this.idUser.set(idUser); }
    public void setIdCust(int idCust) { this.idCust.set(idCust); }
    public void setIdCabang(int idCabang) { this.idCabang.set(idCabang); }
    public void setTotalHarga(double totalHarga) { this.totalHarga.set(totalHarga); }
    public void setPayment(double payment) { this.payment.set(payment); }
    public void setKembalian(double kembalian) { this.kembalian.set(kembalian); }
    public void setTipeTransaksi(String tipeTransaksi) { this.tipeTransaksi.set(tipeTransaksi); }
    public void setStatusTransaksi(String statusTransaksi) { this.statusTransaksi.set(statusTransaksi); }
}