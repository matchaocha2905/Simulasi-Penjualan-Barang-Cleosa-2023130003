package controller;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import model.Penjualan; // Pastikan package model sudah benar

public class PenjualanController implements Initializable {

    @FXML
    private TableView<Penjualan> penjualanTable;
    @FXML
    private TableColumn<Penjualan, Integer> idColumn;
    @FXML
    private TableColumn<Penjualan, Integer> idUserColumn;
    @FXML
    private TableColumn<Penjualan, Integer> idCustColumn;
    @FXML
    private TableColumn<Penjualan, Integer> idCabangColumn;
    @FXML
    private TableColumn<Penjualan, Double> totalHargaColumn;
    @FXML
    private TableColumn<Penjualan, Double> paymentColumn;
    @FXML
    private TableColumn<Penjualan, Double> kembalianColumn;
    @FXML
    private TableColumn<Penjualan, String> tipeTransaksiColumn;
    @FXML
    private TableColumn<Penjualan, String> statusTransaksiColumn;

    private ObservableList<Penjualan> dataPenjualan;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // 1. Inisialisasi kolom tabel
        initColumns();

        // 2. Muat data (misalnya dari database)
        loadData();
    }

    private void initColumns() {
        // Menggunakan nama properti dari kelas Penjualan.java
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        idUserColumn.setCellValueFactory(new PropertyValueFactory<>("idUser"));
        idCustColumn.setCellValueFactory(new PropertyValueFactory<>("idCust"));
        idCabangColumn.setCellValueFactory(new PropertyValueFactory<>("idCabang"));
        totalHargaColumn.setCellValueFactory(new PropertyValueFactory<>("totalHarga"));
        paymentColumn.setCellValueFactory(new PropertyValueFactory<>("payment"));
        kembalianColumn.setCellValueFactory(new PropertyValueFactory<>("kembalian"));
        tipeTransaksiColumn.setCellValueFactory(new PropertyValueFactory<>("tipeTransaksi"));
        statusTransaksiColumn.setCellValueFactory(new PropertyValueFactory<>("statusTransaksi"));
    }

    private void loadData() {
        // **TODO: Ganti dengan logika untuk memuat data dari database SQL Anda**

        // Contoh memuat data dummy:
        dataPenjualan = FXCollections.observableArrayList(
            new Penjualan(1, 101, 201, 301, 150000.00, 150000.00, 0.00, "Tunai", "Selesai"),
            new Penjualan(2, 102, 202, 301, 350500.50, 400000.00, 49499.50, "Debit", "Selesai"),
            new Penjualan(3, 103, 201, 302, 20000.00, 0.00, 0.00, "Tunai", "Pending")
        );
        
        penjualanTable.setItems(dataPenjualan);
    }
    
    // Anda bisa menambahkan method lain di sini, seperti:
    // public void handleTambahPenjualan() { ... }
    // public void handleEditPenjualan() { ... }
}